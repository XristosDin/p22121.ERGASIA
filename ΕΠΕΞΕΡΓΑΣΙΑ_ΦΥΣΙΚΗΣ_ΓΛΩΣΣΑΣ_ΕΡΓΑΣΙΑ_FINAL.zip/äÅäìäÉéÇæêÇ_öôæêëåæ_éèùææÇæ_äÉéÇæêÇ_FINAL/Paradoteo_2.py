
"""
ΠΑΡΑΔΟΤΕΟ 2 - ΥΠΟΛΟΓΙΣΤΙΚΗ ΑΝΑΛΥΣΗ
1. Υπολογισμός ομοιότητας (GloVe, BERT)
2. Οπτικοποίηση με PCA
"""

import numpy as np
from sklearn.metrics.pairwise import cosine_similarity
from sklearn.decomposition import PCA
import matplotlib.pyplot as plt
import gensim.downloader as api
from transformers import BertTokenizer, BertModel
import torch


print("Φόρτωση μοντέλων...")
glove = api.load("glove-wiki-gigaword-300")  
bert_tokenizer = BertTokenizer.from_pretrained('bert-base-uncased')
bert_model = BertModel.from_pretrained('bert-base-uncased')

original = [
    "Hope you too, to enjoy it as my deepest wishes.",
    "the updates was confusing as it not included the full feedback from reviewer or maybe editor?"
]
reconstructed = [
    "I hope you enjoy it as well, with my best wishes.",
    "The updates were confusing because they did not include the complete reviewer/editor feedback."
]

def glove_embedding(text, model):
    """Ενσωμάτωση με GloVe (μέσος όρος λέξεων)"""
    words = text.lower().split()
    vectors = [model[word] for word in words if word in model]
    return np.mean(vectors, axis=0) if vectors else np.zeros(model.vector_size)

def bert_embedding(text):
    """Ενσωμάτωση με BERT (μέσος όρος tokens)"""
    inputs = bert_tokenizer(text, return_tensors='pt', truncation=True, padding=True)
    with torch.no_grad():
        outputs = bert_model(**inputs)
    return outputs.last_hidden_state.mean(dim=1).numpy().flatten()

print("\nΥπολογισμός ομοιότητας...")
results = []
for i, (orig, rec) in enumerate(zip(original, reconstructed), 1):

    orig_glove = glove_embedding(orig, glove)
    rec_glove = glove_embedding(rec, glove)
    sim_glove = cosine_similarity([orig_glove], [rec_glove])[0][0]
    orig_bert = bert_embedding(orig)
    rec_bert = bert_embedding(rec)
    sim_bert = cosine_similarity([orig_bert], [rec_bert])[0][0]
    results.append({
        "Πρόταση": i,
        "GloVe Ομοιότητα": f"{sim_glove:.3f}",
        "BERT Ομοιότητα": f"{sim_bert:.3f}"
    })

print("\nΠίνακας Ομοιότητας:")
for res in results:
    print(f"Πρόταση {res['Πρόταση']}: GloVe = {res['GloVe Ομοιότητα']}, BERT = {res['BERT Ομοιότητα']}")


def plot_pca(orig_embs, rec_embs, title):
    """Οπτικοποίηση ενσωματώσεων με PCA"""
    all_embs = np.vstack([orig_embs, rec_embs])
    pca = PCA(n_components=2)
    reduced = pca.fit_transform(all_embs)
    
    plt.figure(figsize=(10, 5))

    plt.scatter(reduced[:, 0], reduced[:, 1], 
               c=['red']*len(orig_embs) + ['blue']*len(rec_embs), 
               label=['Αρχικό']*len(orig_embs) + ['Ανακατασκευή']*len(rec_embs))
    

    for i in range(min(len(orig_embs), 2)):  
        plt.text(reduced[i, 0]+0.1, reduced[i, 1]+0.1, f"O{i+1}", color='red')
        plt.text(reduced[i+len(orig_embs), 0]+0.1, reduced[i+len(orig_embs), 1]+0.1, f"R{i+1}", color='blue')
    
    plt.title(f"PCA - {title}")
    plt.legend()
    plt.grid()
    plt.show()

print("\nΔημιουργία γραφημάτων PCA...")

orig_glove = [glove_embedding(s, glove) for s in original]
rec_glove = [glove_embedding(s, glove) for s in reconstructed]
plot_pca(orig_glove, rec_glove, "GloVe Ενσωματώσεις")


orig_bert = [bert_embedding(s) for s in original]
rec_bert = [bert_embedding(s) for s in reconstructed]
plot_pca(orig_bert, rec_bert, "BERT Ενσωματώσεις")

print("\nΟλοκλήρωση παραδοτέου 2!")