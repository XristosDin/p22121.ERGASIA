import re  
from transformers import T5ForConditionalGeneration, T5Tokenizer
import torch

class ProfessionalReconstructor:
    def __init__(self):
        self.model = T5ForConditionalGeneration.from_pretrained("t5-small")
        self.tokenizer = T5Tokenizer.from_pretrained("t5-small")
        self.device = "cuda" if torch.cuda.is_available() else "cpu"
        self.model.to(self.device)
        
        self.correction_rules = {
            r'\bto enjoy\b': 'enjoy',
            r'\bdeepest wishes\b': 'best regards',
            r'\bwas\b': 'were',
            r'\bnot included\b': 'lacked'
        }

    def apply_rules(self, text):
        for pattern, repl in self.correction_rules.items():
            text = re.sub(pattern, repl, text, flags=re.IGNORECASE)
        return text

    def reconstruct(self, text):
        corrected = self.apply_rules(text)
        input_text = f"rewrite to academic English: {corrected}"
        input_ids = self.tokenizer.encode(input_text, return_tensors="pt").to(self.device)
        
        outputs = self.model.generate(
            input_ids,
            max_length=150,
            num_beams=5,
            early_stopping=True,
            no_repeat_ngram_size=2
        )
        
        return self.tokenizer.decode(outputs[0], skip_special_tokens=True)


if __name__ == "__main__":
    reconstructor = ProfessionalReconstructor()
    sentences = [
        "Hope you too, to enjoy it as my deepest wishes.",
        "the updates was confusing as it not included the full feedback from reviewer or maybe editor?"
    ]

    print("=== Επαγγελματική Ανακατασκευή ===")
    for i, sent in enumerate(sentences, 1):
        print(f"\nΠρωτότυπη {i}: {sent}")
        print(f"Ανακατασκευή: {reconstructor.reconstruct(sent)}")