import spacy
from textblob import TextBlob
from transformers import pipeline, set_seed
import re


nlp = spacy.load("en_core_web_lg")
text2text_generator = pipeline("text2text-generation", model="t5-base", device="cpu")
set_seed(42)

def reconstruct_with_spacy(text):
    """Εξειδικευμένος μετασχηματισμός με κανόνες και σύνταξη"""
    doc = nlp(text)

    replacements = {
        r'\bdragon boat festival\b': 'Dragon Boat Festival',
        r'\bfinal discuss\b': 'final discussion',
        r'\bour Chinese culture\b': 'Chinese cultural traditions',
        r'\ball safe and great\b': 'safety and prosperity'
    }
    
    reconstructed = []
    for sent in doc.sents:
        new_sent = sent.text
        for pattern, repl in replacements.items():
            new_sent = re.sub(pattern, repl, new_sent, flags=re.IGNORECASE)
        reconstructed.append(new_sent)
    
    return " ".join(reconstructed)

def reconstruct_with_textblob(text):
    """Βελτιωμένη διόρθωση με TextBlob + προσαρμοσμένους κανόνες"""
    blob = TextBlob(text)

    corrections = {
        'discuss': 'discussion',
        'autumn': 'fall',
        'our Chinese': 'Chinese'
    }
    
    corrected = str(blob.correct())
    for wrong, right in corrections.items():
        corrected = corrected.replace(wrong, right)

    if ", " in corrected:
        parts = corrected.split(", ", 1)
        corrected = f"{parts[0]}. {parts[1].capitalize()}"
    
    return corrected

def reconstruct_with_transformers(text):
    """Επαγγελματική επαναδιατύπωση με T5"""
    prompt = (
        "Rephrase this text professionally while preserving all key information. "
        "Fix grammatical errors and improve clarity:\n\n"
        f"{text}"
    )
    
    output = text2text_generator(
        prompt,
        max_new_tokens=256,
        num_beams=5,
        temperature=0.7,
        no_repeat_ngram_size=2
    )
    
    return output[0]['generated_text'].strip()

text1 = """Today is our dragon boat festival, in our Chinese culture, to celebrate it with all safe and great in our lives. Hope you too, to enjoy it as my deepest wishes.
Thank your message to show our words to the doctor, as his next contract checking, to all of us.
I got this message to see the approved message. In fact, I have received the message from the professor, to show me, this, a couple of days ago. I am very appreciated the full support of the professor, for our Springer proceedings publication"""

text2 = """During our final discuss, I told him about the new submission — the one we were waiting since last autumn, but the updates was confusing as it not included the full feedback from reviewer or maybe editor?
Anyway, I believe the team, although bit delay and less communication at recent days, they really tried best for paper and cooperation. We should be grateful, I mean all of us, for the acceptance and efforts until the Springer link came finally last week, I think.
Also, kindly remind me please, if the doctor still plan for the acknowledgments section edit before he sending again. Because I didn’t see that part final yet, or maybe I missed, I apologize if so.
Overall, let us make sure all are safe and celebrate the outcome with strong coffee and future targets"""

def process_text(text, title):
    print(f"\n=== {title} ===")
    print("\nOriginal:")
    print(text)
    
    print("\nspaCy Reconstructed:")
    print(reconstruct_with_spacy(text))
    
    print("\nTextBlob Reconstructed:")
    print(reconstruct_with_textblob(text))
    
    print("\nTransformers Reconstructed:")
    print(reconstruct_with_transformers(text))

process_text(text1, "Κείμενο 1 - Dragon Boat Festival")
process_text(text2, "Κείμενο 2 - Paper Submission")