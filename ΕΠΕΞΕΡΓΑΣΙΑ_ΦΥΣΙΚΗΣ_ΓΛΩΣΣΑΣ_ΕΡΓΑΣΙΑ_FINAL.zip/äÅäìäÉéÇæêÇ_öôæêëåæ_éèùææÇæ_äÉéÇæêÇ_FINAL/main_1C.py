import pandas as pd
from textblob import TextBlob
from transformers import pipeline
import spacy
from spacy.util import is_package

try:
    import tabulate  
except ImportError:
    print("Παρακαλώ εγκαταστήστε τη βιβλιοθήκη tabulate με:")
    print("pip install tabulate")
    exit(1)

try:
    if not is_package("en_core_web_sm"):
        raise OSError("Model not found")
    nlp = spacy.load("en_core_web_sm")
except OSError:
    print("Παρακαλώ εκτελέστε πρώτα:")
    print("python -m spacy download en_core_web_sm")
    exit(1)

text2text = pipeline("text2text-generation", model="t5-small", device="cpu")

def spacy_reconstruct(text):
    doc = nlp(text)
    return " ".join([sent.text for sent in doc.sents])

def textblob_reconstruct(text):
    return str(TextBlob(text).correct())

def transformer_reconstruct(text):
    output = text2text(f"rewrite professionally: {text}", max_length=200)[0]['generated_text']
    return output.split(":", 1)[-1].strip()

sentences = [
    "Hope you too, to enjoy it as my deepest wishes.",
    "the updates was confusing as it not included the full feedback from reviewer or maybe editor?"
]

results = []
for idx, sent in enumerate(sentences, 1):
    results.append({
        "Πρόταση": idx,
        "Πρωτότυπο": sent,
        "spaCy": spacy_reconstruct(sent),
        "TextBlob": textblob_reconstruct(sent),
        "Transformers": transformer_reconstruct(sent)
    })

df = pd.DataFrame(results)
try:
    print(df.to_markdown(index=False))
except:
    print("\nΕναλλακτική έκδοση (χωρίς markdown formatting):")
    print(df.to_string(index=False))